# Rayvora — launch bundle

**Rayvora** is the working brand for a sun-aware travel assistant: enter a journey and it estimates which side of the vehicle receives less direct sunlight.

## Included
- `website/` — responsive web prototype with place search, route calculation, solar analysis and result UI.
- `mobile/` — Expo/React Native Android+iOS prototype with location permission, routing, solar analysis and a native map.
- `deployment/` — production launch checklist and architecture notes.

## Important
Rayvora is a working project/brand name chosen for this build. Before buying a domain, publishing, or registering a company/trademark, check domain availability, Google Play/App Store identifiers, and trademark conflicts in the target markets.

The current prototype uses public OpenStreetMap Nominatim and OSRM endpoints directly for demonstration. For production, put geocoding/routing/sun calculations behind your own HTTPS API, add rate limits, monitoring, dependency/security scanning, and publish an accurate privacy policy.
