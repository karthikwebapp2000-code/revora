import React, {useState} from "react";
import {View, Text, TextInput, Pressable, StyleSheet, Alert, ScrollView, ActivityIndicator} from "react-native";
import MapView, {Polyline, Marker} from "react-native-maps";
import * as Location from "expo-location";

const deg = Math.PI/180;
const rad = 180/Math.PI;

function hav(a,b){
  const R=6371000, p1=a.lat*deg, p2=b.lat*deg, dp=(b.lat-a.lat)*deg, dl=(b.lon-a.lon)*deg;
  const x=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;
  return R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));
}
function bearing(a,b){
  const p1=a.lat*deg,p2=b.lat*deg,dl=(b.lon-a.lon)*deg;
  return (Math.atan2(Math.sin(dl)*Math.cos(p2),Math.cos(p1)*Math.sin(p2)-Math.sin(p1)*Math.cos(p2)*Math.cos(dl))*rad+360)%360;
}

/* NOAA-style solar position approximation. Returns azimuth (clockwise from north)
   and elevation in degrees for local JS Date + coordinate. */
function solarPosition(date,lat,lon){
  const jd=date.getTime()/86400000+2440587.5, n=jd-2451545.0;
  const L=(280.460+0.9856474*n)%360;
  const g=(357.528+0.9856003*n)%360;
  const lambda=(L+1.915*Math.sin(g*deg)+0.020*Math.sin(2*g*deg))*deg;
  const eps=(23.4393-0.0000004*n)*deg;
  const dec=Math.asin(Math.sin(eps)*Math.sin(lambda));
  const ra=Math.atan2(Math.cos(eps)*Math.sin(lambda),Math.cos(lambda));
  let sid=(280.46061837+360.98564736629*(jd-2451545)+lon)%360;
  if(sid<0)sid+=360;
  let H=((sid-(ra*rad)+540)%360-180)*deg;
  const phi=lat*deg;
  const el=Math.asin(Math.sin(phi)*Math.sin(dec)+Math.cos(phi)*Math.cos(dec)*Math.cos(H));
  const az=(Math.atan2(Math.sin(H),Math.cos(H)*Math.sin(phi)-Math.tan(dec)*Math.cos(phi))*rad+180)%360;
  return {azimuth:az,elevation:el*rad};
}
function angleDiff(a,b){return ((a-b+540)%360)-180;}
function sideExposure(sunAz, sunEl, heading, side){
  if(sunEl<=0)return 0;
  const normal=(heading+(side==="right"?90:-90)+360)%360;
  const incidence=Math.max(0,Math.cos(angleDiff(sunAz,normal)*deg));
  return incidence*Math.sin(sunEl*deg);
}

async function geocode(q){
  const u=`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=in&q=${encodeURIComponent(q)}`;
  const r=await fetch(u,{headers:{"Accept-Language":"en"}});
  if(!r.ok)throw new Error("Place search failed");
  const d=await r.json();
  if(!d.length)throw new Error(`Could not find "${q}"`);
  return {lat:+d[0].lat,lon:+d[0].lon,name:d[0].display_name};
}
async function route(a,b){
  const u=`https://router.project-osrm.org/route/v1/driving/${a.lon},${a.lat};${b.lon},${b.lat}?overview=full&geometries=geojson`;
  const r=await fetch(u);
  if(!r.ok)throw new Error("Route service failed");
  const d=await r.json();
  if(!d.routes?.length)throw new Error("No route found");
  return d.routes[0];
}

function analyseRoute(route,startTime){
  const c=route.geometry.coordinates.map(x=>({lat:x[1],lon:x[0]}));
  let left=0,right=0,total=0;
  const stepMs=route.duration*1000/Math.max(1,c.length-1);
  for(let i=0;i<c.length-1;i++){
    const a=c[i],b=c[i+1],dist=hav(a,b);
    if(dist<1)continue;
    const h=bearing(a,b), mid={lat:(a.lat+b.lat)/2,lon:(a.lon+b.lon)/2};
    const t=new Date(startTime.getTime()+stepMs*i);
    const sun=solarPosition(t,mid.lat,mid.lon);
    left += dist*sideExposure(sun.azimuth,sun.elevation,h,"left");
    right += dist*sideExposure(sun.azimuth,sun.elevation,h,"right");
    total += dist;
  }
  const preferred=left<=right?"Left side":"Right side";
  const lower=Math.min(left,right), higher=Math.max(left,right);
  const reduction=higher>0?Math.round((1-lower/higher)*100):0;
  return {preferred,left,right,reduction,points:c,distance:total};
}

export default function Home(){
  const [from,setFrom]=useState(""),[to,setTo]=useState(""),[time,setTime]=useState("");
  const [loading,setLoading]=useState(false),[result,setResult]=useState(null);

  async function useCurrent(){
    const {status}=await Location.requestForegroundPermissionsAsync();
    if(status!=="granted"){Alert.alert("Location permission","Allow location access to use your current position.");return;}
    const p=await Location.getCurrentPositionAsync({accuracy:Location.Accuracy.Balanced});
    setFrom(`${p.coords.latitude.toFixed(5)}, ${p.coords.longitude.toFixed(5)}`);
  }
  async function findShade(){
    if(!from.trim()||!to.trim()){Alert.alert("Missing journey","Enter departure and destination.");return;}
    setLoading(true);setResult(null);
    try{
      const a=await geocode(from), b=await geocode(to);
      const r=await route(a,b);
      const start=time?new Date(time):new Date();
      const analysis=analyseRoute(r,start);
      setResult({...analysis,from:a,to:b,duration:r.duration});
    }catch(e){Alert.alert("Could not calculate",e.message||"Please try again.");}
    finally{setLoading(false);}
  }

  const poly=result?.points?.map(p=>({latitude:p.lat,longitude:p.lon}));
  return <ScrollView style={s.page} contentContainerStyle={s.content}>
    <View style={s.sun}><Text style={s.sunText}>☀</Text></View>
    <Text style={s.kicker}>SHADESEAT</Text>
    <Text style={s.title}>Find your{"\n"}cooler side.</Text>
    <Text style={s.subtitle}>Route + sun position → a simple left or right seat suggestion.</Text>

    <View style={s.card}>
      <View style={s.row}><Text style={s.pin}>●</Text><View style={s.flex}>
        <Text style={s.label}>From</Text>
        <TextInput value={from} onChangeText={setFrom} placeholder="City, station or place" placeholderTextColor="#a2aaba" style={s.input}/>
      </View><Pressable onPress={useCurrent} style={s.loc}><Text style={s.locText}>◎</Text></Pressable></View>
      <View style={s.line}/>
      <View style={s.row}><Text style={s.pin}>●</Text><View style={s.flex}>
        <Text style={s.label}>To</Text>
        <TextInput value={to} onChangeText={setTo} placeholder="City, station or place" placeholderTextColor="#a2aaba" style={s.input}/>
      </View></View>
      <View style={{marginTop:22}}>
        <Text style={s.label}>Departure time (optional)</Text>
        <TextInput value={time} onChangeText={setTime} placeholder="2026-10-03 14:30" placeholderTextColor="#a2aaba" style={s.input}/>
      </View>
      <Pressable onPress={findShade} disabled={loading} style={[s.button,loading&&s.disabled]}>
        {loading?<ActivityIndicator color="#fff"/>:<Text style={s.buttonText}>Find the shade →</Text>}
      </Pressable>
      <Text style={s.fine}>Place search and routing use public OpenStreetMap/OSRM services in this prototype.</Text>
    </View>

    {result&&<View style={s.result}>
      <Text style={s.resultEmoji}>🪟</Text>
      <Text style={s.resultTitle}>Take the {result.preferred}</Text>
      <Text style={s.resultText}>Estimated route: {Math.round(result.duration/60)} min · about {Math.round(result.distance/100)/10} km</Text>
      <View style={s.compare}>
        <View style={s.metric}><Text style={s.metricLabel}>LEFT</Text><Text style={s.metricValue}>{result.left.toFixed(1)}</Text></View>
        <View style={s.metric}><Text style={s.metricLabel}>RIGHT</Text><Text style={s.metricValue}>{result.right.toFixed(1)}</Text></View>
      </View>
      <Text style={s.note}>Estimated reduction in direct-sun exposure: ~{result.reduction}% on the recommended side. Buildings, trees, weather and vehicle orientation can change real-world exposure.</Text>
      <MapView style={s.map} initialRegion={{latitude:result.from.lat,longitude:result.from.lon,latitudeDelta:Math.max(.05,Math.abs(result.from.lat-result.to.lat)*1.6),longitudeDelta:Math.max(.05,Math.abs(result.from.lon-result.to.lon)*1.6)}} showsUserLocation={false}>
        <Marker coordinate={{latitude:result.from.lat,longitude:result.from.lon}} title="From"/>
        <Marker coordinate={{latitude:result.to.lat,longitude:result.to.lon}} title="To"/>
        <Polyline coordinates={poly} strokeWidth={5}/>
      </MapView>
    </View>}

    <Text style={s.footer}>No account required · Rayvora 2.0</Text>
  </ScrollView>
}

const s=StyleSheet.create({
 page:{flex:1,backgroundColor:"#fff"},content:{padding:22,paddingTop:54,paddingBottom:45},
 sun:{width:108,height:108,borderRadius:54,backgroundColor:"#ffd13d",alignSelf:"center",alignItems:"center",justifyContent:"center",borderWidth:4,borderColor:"#111",marginBottom:20,shadowColor:"#e7b000",shadowOffset:{width:8,height:8},shadowOpacity:.35,shadowRadius:0},
 sunText:{fontSize:50,color:"#111"},kicker:{textAlign:"center",fontSize:12,fontWeight:"800",letterSpacing:3,color:"#6b7586"},
 title:{fontSize:50,lineHeight:49,fontWeight:"800",letterSpacing:-2,color:"#172033",textAlign:"center",marginTop:7},
 subtitle:{fontSize:16,lineHeight:24,color:"#697487",textAlign:"center",marginTop:14,marginBottom:26},
 card:{backgroundColor:"#fff",borderRadius:24,padding:20,borderWidth:1,borderColor:"#e8ebf0",shadowColor:"#182338",shadowOpacity:.08,shadowRadius:18,elevation:3},
 row:{flexDirection:"row",alignItems:"flex-start"},flex:{flex:1},pin:{fontSize:18,color:"#596579",marginTop:31,marginRight:12},
 label:{fontSize:13,fontWeight:"700",color:"#536075",marginBottom:5},input:{fontSize:18,color:"#172033",paddingVertical:9,borderBottomWidth:2,borderBottomColor:"#dce1e9"},
 loc:{width:42,height:42,borderRadius:13,backgroundColor:"#f1f3f6",alignItems:"center",justifyContent:"center",marginTop:21,marginLeft:9},locText:{fontSize:24,color:"#5a6679"},
 line:{height:27,borderLeftWidth:2,borderStyle:"dotted",borderColor:"#d9dee7",marginLeft:7},
 button:{height:57,borderRadius:17,backgroundColor:"#111827",alignItems:"center",justifyContent:"center",marginTop:25},disabled:{opacity:.55},buttonText:{color:"#fff",fontSize:18,fontWeight:"800"},
 fine:{textAlign:"center",color:"#8993a2",fontSize:10,lineHeight:15,marginTop:10},
 result:{marginTop:18,padding:18,borderRadius:22,backgroundColor:"#f7f8fa",borderWidth:1,borderColor:"#e5e8ee",alignItems:"center"},resultEmoji:{fontSize:36},resultTitle:{fontSize:24,fontWeight:"800",color:"#172033",marginTop:4},resultText:{fontSize:13,color:"#697487",marginTop:6},
 compare:{width:"100%",flexDirection:"row",gap:10,marginTop:16},metric:{flex:1,backgroundColor:"#fff",borderRadius:15,padding:13,alignItems:"center"},metricLabel:{fontSize:11,fontWeight:"800",color:"#7a8493"},metricValue:{fontSize:21,fontWeight:"800",color:"#172033",marginTop:3},
 note:{fontSize:11,color:"#7c8798",textAlign:"center",lineHeight:17,marginTop:14},map:{width:"100%",height:230,borderRadius:18,marginTop:16,overflow:"hidden"},footer:{textAlign:"center",fontSize:11,color:"#8a94a4",marginTop:28}
});