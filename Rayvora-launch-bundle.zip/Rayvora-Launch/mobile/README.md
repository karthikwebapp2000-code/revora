# Rayvora Mobile 2.0

This version replaces the random demo result with a real prototype pipeline:

1. Geocode departure and destination with OpenStreetMap Nominatim.
2. Request a driving route from OSRM.
3. Sample route geometry.
4. Calculate approximate solar azimuth/elevation for each route sample.
5. Estimate direct-sun exposure on the left and right vehicle sides.
6. Recommend the side with lower modeled exposure.
7. Display the route on a native mobile map.

## Run on a phone
Install Node.js LTS, extract this project, then:

```bash
npm install
npx expo start
```

Install Expo Go on Android/iPhone and scan the QR code. If LAN discovery fails:

```bash
npx expo start --tunnel
```

## Build an installable Android APK
An Android SDK/Gradle environment is required for a local APK. With Android Studio installed:

```bash
npx expo prebuild
npx expo run:android
```

For a cloud build, configure an EAS project and run:

```bash
npx eas build -p android --profile preview
```

## Production caveats
- The public Nominatim and OSRM endpoints are suitable for prototyping, not guaranteed production scale.
- For launch, use a properly provisioned geocoding/routing provider or your own infrastructure, with caching and rate limits.
- The solar model is an estimate; shade from buildings/trees and vehicle geometry needs additional modeling for higher accuracy.
- Add a backend for saved routes, accounts, analytics/consent and abuse protection.
